import { Theme } from './settings/types';
import { RedwingsCoffeePlataformaIntegral } from './components/generated/RedwingsCoffeePlataformaIntegral';

let theme: Theme = 'light';

function App() {
  function setTheme(theme: Theme) {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  setTheme(theme);

  return (
    <>
      <RedwingsCoffeePlataformaIntegral />
    </>
  ); // %EXPORT_STATEMENT%
}

export default App;
